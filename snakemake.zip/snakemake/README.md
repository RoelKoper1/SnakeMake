# EindopdrachtOWE11

Deze workflow is gemaakt om in een environment in Vagrant uitgevoerd te worden.

Voor deze workflow moet de gebruiker Snakemake installeren.

Deze workflow is uit te voeren door het volgende in de terminal te typen:

### snakemake results




De resultaten zijn te vinden in results.txt in de hoofdmap waar het Snakefile zich bevindt.

Het rapport toon eerst de gene ID's gesorteerd op het aantal voorkomen in PubMed Artikelen.
Hierna is een rapport voor elk gen te vinden.


## In het rapport staat de volgende informatie:
-Gene ID

-Converted Gene ID

-Sequence

-Function

-Pubmed entries

-Pathway


### De workflow is te zien in dag.pdf in de hoofdmap

de workflow bestaat uit 9 stappen waarbij alles samenkomt in de stap *results*
